from datetime import datetime
from typing import Optional
from pydantic import BaseModel
from app.models.task import PriorityEnum


class TaskBase(BaseModel):
    title: str
    description: Optional[str] = ""
    priority: PriorityEnum = PriorityEnum.medium
    due_date: Optional[datetime] = None


class TaskCreate(TaskBase):
    pass


class TaskUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    completed: Optional[bool] = None
    priority: Optional[PriorityEnum] = None
    due_date: Optional[datetime] = None


class TaskOut(TaskBase):
    id: int
    completed: bool
    created_at: datetime
    updated_at: Optional[datetime] = None
    owner_id: int

    class Config:
        from_attributes = True
