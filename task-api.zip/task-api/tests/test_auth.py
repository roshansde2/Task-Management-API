def test_register_user(client):
    response = client.post(
        "/api/auth/register",
        json={"username": "alice", "email": "alice@example.com", "password": "secret123"},
    )
    assert response.status_code == 201
    data = response.json()
    assert data["username"] == "alice"
    assert "id" in data


def test_register_duplicate_username(client):
    client.post(
        "/api/auth/register",
        json={"username": "bob", "email": "bob@example.com", "password": "secret123"},
    )
    response = client.post(
        "/api/auth/register",
        json={"username": "bob", "email": "bob2@example.com", "password": "secret123"},
    )
    assert response.status_code == 400


def test_login_success(client):
    client.post(
        "/api/auth/register",
        json={"username": "carol", "email": "carol@example.com", "password": "secret123"},
    )
    response = client.post(
        "/api/auth/login",
        data={"username": "carol", "password": "secret123"},
    )
    assert response.status_code == 200
    assert "access_token" in response.json()


def test_login_wrong_password(client):
    client.post(
        "/api/auth/register",
        json={"username": "dave", "email": "dave@example.com", "password": "secret123"},
    )
    response = client.post(
        "/api/auth/login",
        data={"username": "dave", "password": "wrongpass"},
    )
    assert response.status_code == 401
