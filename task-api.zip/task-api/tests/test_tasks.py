def register_and_login(client, username="taskuser"):
    client.post(
        "/api/auth/register",
        json={"username": username, "email": f"{username}@example.com", "password": "secret123"},
    )
    response = client.post(
        "/api/auth/login", data={"username": username, "password": "secret123"}
    )
    token = response.json()["access_token"]
    return {"Authorization": f"Bearer {token}"}


def test_create_task(client):
    headers = register_and_login(client)
    response = client.post(
        "/api/tasks",
        json={"title": "Write tests", "description": "Cover the task API", "priority": "high"},
        headers=headers,
    )
    assert response.status_code == 201
    data = response.json()
    assert data["title"] == "Write tests"
    assert data["completed"] is False


def test_list_tasks_requires_auth(client):
    response = client.get("/api/tasks")
    assert response.status_code == 401


def test_update_task(client):
    headers = register_and_login(client, "updater")
    create_resp = client.post(
        "/api/tasks", json={"title": "Old title"}, headers=headers
    )
    task_id = create_resp.json()["id"]

    update_resp = client.put(
        f"/api/tasks/{task_id}",
        json={"title": "New title", "completed": True},
        headers=headers,
    )
    assert update_resp.status_code == 200
    assert update_resp.json()["title"] == "New title"
    assert update_resp.json()["completed"] is True


def test_delete_task(client):
    headers = register_and_login(client, "deleter")
    create_resp = client.post(
        "/api/tasks", json={"title": "Temporary task"}, headers=headers
    )
    task_id = create_resp.json()["id"]

    delete_resp = client.delete(f"/api/tasks/{task_id}", headers=headers)
    assert delete_resp.status_code == 204

    get_resp = client.get(f"/api/tasks/{task_id}", headers=headers)
    assert get_resp.status_code == 404


def test_tasks_are_scoped_to_owner(client):
    headers_a = register_and_login(client, "usera")
    headers_b = register_and_login(client, "userb")

    create_resp = client.post("/api/tasks", json={"title": "User A task"}, headers=headers_a)
    task_id = create_resp.json()["id"]

    response = client.get(f"/api/tasks/{task_id}", headers=headers_b)
    assert response.status_code == 404
